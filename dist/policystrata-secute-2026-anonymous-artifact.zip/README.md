# PolicyStrata Anonymous Artifact

This is the double-anonymous review artifact for the SECUTE 2026 tool/data-paper
submission. It packages the deterministic PolicyStrata scanner, benchmark,
fixtures, tests, and an anonymous security-case fixture.

## Requirements

- Python 3.10 or newer
- uv
- Docker only for optional PostgreSQL fixture checks
- No LLM API key
- No host psql

## Smoke Commands

```sh
uv run --extra dev ruff check .
uv run --extra dev mypy src
uv run --extra dev pytest
```

## Main Reproduction

```sh
POLICYSTRATA_RUN_ROOT=/tmp/policystrata-final ./scripts/reproduce-final.sh
```

Expected deterministic summary: 1720/1720 injected non-clean cases killed and
0 false positives on 80 clean controls. The generated report is written to:

```text
/tmp/policystrata-final/evidence.md
```

## SECUTE Security Fixture

```sh
uv run policystrata doctor \
  --config examples/secute_security_cases/policystrata.yaml \
  --format markdown \
  --out /tmp/policystrata-secute-doctor.md

uv run policystrata scan \
  --config examples/secute_security_cases/policystrata.yaml \
  --out /tmp/policystrata-secute-scan
```

The security fixture is expected to fail the CI gate. It contains three
representative cross-layer failures:

- unauthorized metric exposure reaching SQL;
- stale tenant-key lowering;
- release of a result whose lineage requires withholding.

The doctor report should show wired policy/TOS/DPA/internal-policy ingestion,
source mapping, export coverage, and partial prompt-manifest checks because the
manifest intentionally exposes unsafe capabilities.
