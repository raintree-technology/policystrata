# Anonymization Notes

This review artifact is generated from the public package source with
double-anonymous review constraints applied:

- public project URLs and public release notes are omitted;
- public GitHub Action documentation is omitted;
- package authorship and license copyright are anonymized;
- brownfield application names and private local paths are excluded;
- generated caches, local run outputs, and node_modules are excluded.

The source package name is preserved because tests and command examples import
the `policystrata` Python package.
